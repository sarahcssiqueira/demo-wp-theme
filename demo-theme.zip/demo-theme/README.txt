WordPress Demo Theme

A simple WordPress Demo Theme, created from a Prototype specially to show some skills.
