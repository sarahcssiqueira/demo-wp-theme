<?php
/**
 * The sidebar containing a widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 */
?>


<?php dynamic_sidebar('sidebar-1');?>
			